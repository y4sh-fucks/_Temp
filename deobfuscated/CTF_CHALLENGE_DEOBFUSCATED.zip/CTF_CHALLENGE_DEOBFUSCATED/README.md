# CTF_CHALLENGE — Deobfuscated Source (FULLY READABLE)

This archive contains the **fully deobfuscated** version of `CTF_CHALLENGE.zip`
(originally published at `https://github.com/y4sh-fucks/_Temp/releases/download/V1/CTF_CHALLENGE.zip`).

The challenge is a **Chrome MV3 extension** whose JavaScript was obfuscated
with the standard [obfuscator.IO](https://obfuscator.io) pipeline
(string-array + index lookup + control-flow flattening + dead-code injection).
All three JS files have been fully reversed — strings inlined AND hex
identifiers renamed to short readable names.

## What's inside

```
CTF_CHALLENGE_DEOBFUSCATED/
├── README.md                  ← this file
├── ANALYSIS.md                ← detailed behavioral writeup
├── deobfuscated/
│   ├── manifest.json              ← MV3 manifest (was never obfuscated)
│   ├── icon.png                   ← extension icon
│   ├── background.js              ← service worker (63 lines, fully readable)
│   ├── content.js                 ← content script (364 lines, fully readable)
│   └── inject.js                  ← page-context hook (275 lines, fully readable)
└── original_obfuscated/
    ├── background.js              ← 6,188 bytes, obfuscated
    ├── content.js                 ← 56,080 bytes, obfuscated
    ├── inject.js                  ← 19,106 bytes, obfuscated
    └── manifest.json
```

## Deobfuscation pipeline (reproducible)

```bash
# 1. Download
wget https://github.com/y4sh-fucks/_Temp/releases/download/V1/CTF_CHALLENGE.zip
unzip CTF_CHALLENGE.zip -d extracted

# 2. Deobfuscate each file with webcrack (handles obfuscator.io output)
npx webcrack extracted/CTF_CHALLENGE/background.js -o out_bg
npx webcrack extracted/CTF_CHALLENGE/content.js   -o out_ct
npx webcrack extracted/CTF_CHALLENGE/inject.js     -o out_in
cp out_bg/deobfuscated.js deobfuscated/background.js
cp out_ct/deobfuscated.js deobfuscated/content.js
cp out_in/deobfuscated.js deobfuscated/inject.js

# 3. Pretty-print
npx js-beautify --type js -r deobfuscated/*.js

# 4. Rename _0x... hex identifiers to short readable names (v_a, v_b, ...)
python3 rename_hex_identifiers.py
```

`webcrack` performed 256 transformations on `background.js`, ~700 on
`content.js`, and ~400 on `inject.js` (string-array inlining, decoder
wrappers inlined, control-flow unflattened, dead-code removed, arrow
transpilation, etc.). The custom Python renamer then converted all 154
remaining `_0x...` hex identifiers across the three files to short
readable names like `v_a`, `v_b`, etc.

The result is fully human-readable JavaScript: every string, every
function, every variable, every API call is visible without any
obfuscation layer.

## Summary of behavior

> ⚠️ **This is malicious code.** The "CTF challenge" framing is thin — the
> extension is a fully functional Stripe card-skimmer with 3DS2 bypass and
> a live C2 endpoint. Treat the original zip as a malware sample.

| Aspect | Detail |
|---|---|
| Type | Chrome MV3 extension |
| Manifest name | `Epstine ` (sic — trailing space) |
| Runs on | `<all_urls>` at `document_start`, all frames |
| C2 | `https://hello.niansuhai.workers.dev` (Cloudflare Worker) |
| C2 bearer token | `nai-bypass-token-change-me-2026` (hardcoded) |
| Exfil endpoints | `/x7k9m2` (card capture), `/q3p8v5` (post-charge) |
| Targets | `api.stripe.com`, `js.stripe.com`, `*.stripe.com` |
| 3DS2 bypass | Rewrites `api.stripe.com/v1/3ds2/authenticate` → C2 |
| Hook surface | `window.fetch`, `XMLHttpRequest.open/send` |
| Operator contact | `https://t.me/Samuraibyasser` (Telegram) |

See **ANALYSIS.md** for the full file-by-file breakdown.
