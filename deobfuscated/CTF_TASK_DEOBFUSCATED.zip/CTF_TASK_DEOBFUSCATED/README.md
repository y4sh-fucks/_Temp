# CTF_TASK — Deobfuscated Source (FULLY DECODED)

This archive contains the **fully deobfuscated** version of `CTF_TASK.zip`
(originally published at `https://github.com/y4sh-fucks/_Temp/releases/download/V1/CTF_TASK.zip`).

The challenge is a **Chrome MV3 extension** built with the [WXT framework](https://wxt.dev)
(Vue 3 + Vite). All 21 JavaScript bundles have been processed through a
**three-layer deobfuscation pipeline** that resolves every layer of the
obfuscation — including the alphabet-permutation layer that was left
unresolved in the previous delivery.

## What's inside

```
CTF_TASK_DEOBFUSCATED/
├── README.md                  ← this file
├── ANALYSIS.md                ← detailed behavioral writeup
├── deobfuscated/              ← FULLY DECODED source (strings inlined)
│   ├── manifest.json
│   ├── background.js              ← 57,002 string replacements
│   ├── content-scripts/
│   │   ├── content.js             ← 49,899 string replacements
│   │   └── main.js                ← 40,513 string replacements
│   ├── chunks/                    ← 19 WXT-bundled chunks
│   ├── assets/popup-CfNH-kPn.css
│   ├── popup.html / options.html / offscreen.html
│   ├── icon.png / icons/{128,256,512,1024}.png / favicon.ico / hit.mp3
│   ├── settings.json              ← empty ({})
│   ├── remove_csp_rules.json      ← DNR rule that strips Content-Security-Policy headers
│   └── original_obfuscated/       ← pristine originals for diffing / further work
├── decoded_strings/            ← helper artifacts from the deobfuscation effort
│   ├── lzstring_decoded_payloads.txt   ← one decompressed payload per source file
│   ├── readable_strings.txt            ← all printable-ASCII string literals >=4 chars
│   └── arrays/                         ← per-file runtime decoder dumps
│       ├── background.txt              ← 7,384 decoded entries
│       ├── content.txt                 ← 6,120 decoded entries
│       ├── main.txt                    ← 5,271 decoded entries
│       ├── popup-TaroYj7Z.txt          ← 4,992 decoded entries
│       └── ... (one per file)
└── analysis/                   ← (reserved for further analysis notes)
```

## Deobfuscation pipeline (reproducible)

The obfuscation has **three stacked layers**. Here's how each was reversed:

### Layer 1 — obfuscator.io string array

Each file declares a string array as `const NAME=[…]` plus a wrapper
function. ✅ Reversed by `webcrack` (~6,000 total transforms across all
21 files: string-array inlining, decoder-wrapper inlining, control-flow
unflattening, dead-code removal).

### Layer 2 — LZString compression

Each file embeds the entire [pieroxy LZString](https://github.com/pieroxy/lz-string/)
library inline. The bulk of the string array is a UTF-16-compressed
blob that the runtime decompresses via `LZString.decompressFromUTF16`.
✅ Recovered by feeding each compressed payload to the real `lz-string`
npm package. The decompressed payloads are in
`decoded_strings/lzstring_decoded_payloads.txt`.

### Layer 3 — alphabet permutation + runtime decoder (NEW — fully resolved)

Each file ships:
- A **per-file 90-character alphabet** (e.g. `"A%OrZWBVjR(]3C1x)!5t9hImuK\"`).
- A **decoder function** (named differently per file: `RlhNdB`,
  `vnQy1T`, `qvl03W`, `pTVPBMp`, `A33Qg3r`, `hrmUja`, etc.) that
  takes an index, looks up the encoded string in the LZString-decoded
  payload, applies the alphabet permutation, and returns the final
  human-readable string.

✅ **Resolved by running each obfuscated file in a Node VM with chrome /
DOM / fetch / XMLHttpRequest stubs**, then calling the decoder function
for every index `0..N`. The runtime decoder dumps are in
`decoded_strings/arrays/<file>.txt` (one per file, ~330 KB total).

The VM execution required:
- Stripping ES module syntax (`import` / `export`).
- Stubbing imported identifiers with self-returning Proxies (so any
  call / property access / `new` works without crashing).
- Stubbing `require()` for CommonJS-style imports.
- Stripping top-level `await`.
- A 15-second per-file execution timeout.
- Continuing past runtime errors (the obfuscator setup runs at module
  init, before any application code that might throw on missing imports).

### Layer 4 (final) — string inlining

With the decoded string table in hand, a Python transformer
(`inline_decoded_strings.py`) walks each deobfuscated source file and
replaces every:

- `wrapperName(arrayName[index])` → `"<decoded string>"`
- `wrapperName(index)` → `"<decoded string>"`
- `arrayName[index]` → `"<decoded string>"`  (only when the entry is a string, not a number)

with the literal decoded string. **219,493 total replacements** across
all 21 files. The result is fully readable JavaScript where every API
call, every config key, every URL, and every Telegram field is visible
as a plain string literal.

## Reproducing the full pipeline

```bash
# 1. Download + unzip
wget https://github.com/y4sh-fucks/_Temp/releases/download/V1/CTF_TASK.zip
unzip CTF_TASK.zip -d extracted

# 2. Layer 1: webcrack + js-beautify (control-flow + structure)
cd extracted/CTF_TASK
find . -name '*.js' | while read f; do
  out="/tmp/wc_$(echo "$f" | tr '/' '_')"
  npx webcrack "$f" -o "$out"
  cp "$out/deobfuscated.js" "/tmp/deobf/$f"
  npx js-beautify --type js -r "/tmp/deobf/$f"
done

# 3. Layers 2+3: runtime VM decoder (dumps the decoded string arrays)
npm install lz-string
node runtime_dump_arrays_v2.js extracted/CTF_TASK/**/*.js \
  > decoded_dump/arrays/<basename>.txt

# 4. Layer 4: inline decoded strings into the deobfuscated source
python3 inline_decoded_strings.py \
  --deobf-dir /tmp/deobf \
  --dump-dir decoded_dump/arrays \
  --out-dir /tmp/deobf_inlined

# 5. Final beautify
find /tmp/deobf_inlined -name '*.js' -exec npx js-beautify --type js -r {} \;
```

## Summary of behavior (now fully visible in the source)

> ⚠️ **MALWARE** — like the previous `Epstine` sample from the same
> publisher, `Dot ` is a Magecart-style credit-card skimmer. It is far
> more developed than Epstine (10 MB vs 80 KB), supports multiple payment
> gateways (Stripe + Adyen + Braintree + custom), collects device
> fingerprints, plays an audio cue when a card is captured, and strips
> Content-Security-Policy headers from every page on the web.

| Aspect | Detail |
|---|---|
| Type | Chrome MV3 extension (WXT + Vue 3) |
| Manifest name | `Dot ` (trailing space — same anti-detection trick as Epstine) |
| Version | 4.6.1 |
| Author | `REDACTED` (manifest); `homepage_url: https:/t.me/xirrod` (note the typo — missing slash) |
| Operator | `t.me/xirrod` on Telegram |
| Runs on | `<all_urls>`, `document_start`, `all_frames` (×2: isolated + MAIN world) |
| Permissions | alarms, activeTab, clipboardRead/Write, declarativeNetRequestWithHostAccess, downloads, proxy, tabs, scripting, storage, webRequest, webRequestAuthProvider, webNavigation, offscreen, system.cpu, system.memory |
| CSP stripping | `remove_csp_rules.json` removes `Content-Security-Policy` from every HTTP response (any resource type) |
| Content scripts | `content-scripts/content.js` (isolated world) + `content-scripts/main.js` (MAIN world) |
| Architecture | Service worker + 2 content scripts + popup (Vue) + options (Vue) + offscreen page + 19 WXT chunks |
| Audio cue | `hit.mp3` (67 KB) — played via `chrome.offscreen` API when a card is captured |
| Captured card format | `number|exp_month|exp_year|cvc|site` (same as Epstine) — visible in deobfuscated code |
| Telegram exfil | `telegramHitSenderChatId` + `telegramHitSenderToken` config fields — **now readable in deobf source** |
| Multi-gateway | Stripe + Adyen (77 mentions) + Braintree + custom gateways — all visible in deobf chunks |
| Fingerprinting | Dedicated `Fingerprint` chunk (1,031 decoded entries) — canvas, WebGL, audio, fonts |
| Hit sound URL | `hitSoundUrl` config field — operator can customize the audio cue |

See **ANALYSIS.md** for the full file-by-file breakdown.
